import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import teacherQuizApi from "../../api/teacherQuizApi";
import styles from "./AddQuestion.module.css";

const AddQuestion = () => {
  const { id: quizId } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    questionText: "",
    type: "QCM",
    points: 1,
    optionA: "",
    optionB: "",
    optionC: "",
    optionD: "",
    correctAnswer: "A",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const buildPayload = () => {
    return {
      enonce: form.questionText.trim(),
      type: form.type === 'QCM' ? 'MCQ' : form.type,
      points: Number(form.points),
      choixA: form.optionA.trim(),
      choixB: form.optionB.trim(),
      choixC: form.optionC.trim(),
      choixD: form.optionD.trim(),
      reponseCorrecte: form.correctAnswer,
    };
  };

  const validateForm = () => {
    if (!form.questionText.trim()) {
      return "L’énoncé de la question est obligatoire.";
    }

    if (!form.points || Number(form.points) <= 0) {
      return "Les points doivent être supérieurs à 0.";
    }

    if (form.type === "QCM") {
      if (
        !form.optionA.trim() ||
        !form.optionB.trim() ||
        !form.optionC.trim() ||
        !form.optionD.trim()
      ) {
        return "Veuillez remplir les quatre choix A, B, C et D.";
      }
    }

    if (!form.correctAnswer) {
      return "Veuillez choisir la bonne réponse.";
    }

    return "";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    const validationError = validateForm();

    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      setLoading(true);

      const payload = buildPayload();

      await teacherQuizApi.addQuestion(quizId, payload);

      navigate(`/teacher/quizzes/${quizId}/questions`);
    } catch (err) {
      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        "Erreur lors de l’ajout de la question.";

      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <span className={styles.badge}>Quiz #{quizId}</span>
          <h1>Ajouter une question</h1>
          <p>Créez une question claire avec ses choix et sa bonne réponse.</p>
        </div>

        <button
          type="button"
          className={styles.backBtn}
          onClick={() => navigate(`/teacher/quizzes/${quizId}/questions`)}
        >
          Retour
        </button>
      </div>

      <form className={styles.card} onSubmit={handleSubmit}>
        {error && <div className={styles.errorBox}>{error}</div>}

        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <span>01</span>
            <div>
              <h2>Informations de la question</h2>
              <p>Définissez l’énoncé, le type et le nombre de points.</p>
            </div>
          </div>

          <div className={styles.field}>
            <label htmlFor="questionText">Énoncé</label>
            <textarea
              id="questionText"
              name="questionText"
              value={form.questionText}
              onChange={handleChange}
              placeholder="Exemple : Qu’est-ce que la cryptographie ?"
              rows="5"
              required
            />
          </div>

          <div className={styles.gridTwo}>
            <div className={styles.field}>
              <label htmlFor="type">Type</label>
              <select
                id="type"
                name="type"
                value={form.type}
                onChange={handleChange}
              >
                <option value="QCM">QCM</option>
                <option value="TRUE_FALSE">Vrai / Faux</option>
                <option value="TEXT">Réponse courte</option>
              </select>
            </div>

            <div className={styles.field}>
              <label htmlFor="points">Points</label>
              <input
                id="points"
                name="points"
                type="number"
                min="1"
                value={form.points}
                onChange={handleChange}
                required
              />
            </div>
          </div>
        </div>

        {form.type === "QCM" && (
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <span>02</span>
              <div>
                <h2>Choix de réponse</h2>
                <p>Chaque choix est affiché dans une ligne séparée.</p>
              </div>
            </div>

            <div className={styles.choicesList}>
              {[
                ["A", "optionA"],
                ["B", "optionB"],
                ["C", "optionC"],
                ["D", "optionD"],
              ].map(([label, name]) => (
                <div className={styles.choiceRow} key={label}>
                  <div className={styles.choiceLetter}>{label}</div>

                  <input
                    name={name}
                    value={form[name]}
                    onChange={handleChange}
                    placeholder={`Choix ${label}`}
                    required
                  />

                  <label className={styles.correctChoice}>
                    <input
                      type="radio"
                      name="correctAnswer"
                      value={label}
                      checked={form.correctAnswer === label}
                      onChange={handleChange}
                    />
                    Bonne réponse
                  </label>
                </div>
              ))}
            </div>
          </div>
        )}

        {form.type !== "QCM" && (
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <span>02</span>
              <div>
                <h2>Bonne réponse</h2>
                <p>Indiquez la réponse correcte attendue.</p>
              </div>
            </div>

            <div className={styles.field}>
              <label htmlFor="correctAnswer">Bonne réponse</label>
              <input
                id="correctAnswer"
                name="correctAnswer"
                value={form.correctAnswer}
                onChange={handleChange}
                placeholder="Exemple : vrai"
                required
              />
            </div>
          </div>
        )}

        <div className={styles.actions}>
          <button
            type="button"
            className={styles.secondaryBtn}
            onClick={() => navigate(`/teacher/quizzes/${quizId}/questions`)}
            disabled={loading}
          >
            Annuler
          </button>

          <button type="submit" className={styles.primaryBtn} disabled={loading}>
            {loading ? "Ajout en cours..." : "Ajouter la question"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddQuestion;