import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Brain,
  Plus,
  Save,
  Trash2,
  Wand2,
} from "lucide-react";

import teacherQuizApi from "../../api/teacherQuizApi";
import styles from "./GenerateQuizAI.module.css";

const createEmptyQCM = () => ({
  questionText: "",
  type: "QCM",
  points: 1,
  correctAnswer: "A",

  options: [
    { label: "A", text: "", correct: true },
    { label: "B", text: "", correct: false },
    { label: "C", text: "", correct: false },
    { label: "D", text: "", correct: false },
  ],
});

const createEmptyTextQuestion = () => ({
  questionText: "",
  type: "TEXT",
  points: 1,
  textAnswer: "",
});

const GenerateQuizAI = () => {
  const navigate = useNavigate();
  const { state } = useLocation();

  const quizInfo = state || {};

  const [questions, setQuestions] = useState([]);
  const [numberOfQuestions, setNumberOfQuestions] = useState(5);

  const [loadingGenerate, setLoadingGenerate] = useState(false);
  const [loadingSave, setLoadingSave] = useState(false);

  const [error, setError] = useState("");

  /* =========================================================
     GENERATE QUESTIONS WITH AI
  ========================================================= */

  const generateQuestions = async () => {
    setError("");

    try {
      setLoadingGenerate(true);

      const payload = {
        titre: quizInfo.titre,
        theme: quizInfo.theme,
        description: quizInfo.description,
        classe: quizInfo.classe,
        difficulty: quizInfo.difficulty,
        numberOfQuestions: Number(numberOfQuestions),
      };

      const response =
        await teacherQuizApi.generateQuestionsAI(payload);

      const generatedQuestions =
        Array.isArray(response)
          ? response
          : response?.questions || [];

      const formattedQuestions = generatedQuestions.map((q) => ({
        questionText: q.questionText || "",
        type: q.type || "QCM",
        points: q.points || 1,

        correctAnswer: q.correctAnswer || "A",

        options:
          q.options?.map((option, index) => ({
            label: option.label || ["A", "B", "C", "D"][index],
            text: option.text || "",
            correct:
              option.label === (q.correctAnswer || "A"),
          })) ||
          createEmptyQCM().options,

        textAnswer: q.textAnswer || "",
      }));

      setQuestions(formattedQuestions);
    } catch (err) {
      setError(
        err?.response?.data?.message ||
          err?.message ||
          "Erreur lors de la génération IA."
      );
    } finally {
      setLoadingGenerate(false);
    }
  };

  /* =========================================================
     QUESTION MANAGEMENT
  ========================================================= */

  const addQuestion = (type = "QCM") => {
    if (type === "TEXT") {
      setQuestions((prev) => [
        ...prev,
        createEmptyTextQuestion(),
      ]);
    } else {
      setQuestions((prev) => [...prev, createEmptyQCM()]);
    }
  };

  const deleteQuestion = (index) => {
    setQuestions((prev) =>
      prev.filter((_, i) => i !== index)
    );
  };

  const updateQuestionField = (
    questionIndex,
    field,
    value
  ) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === questionIndex
          ? {
              ...q,
              [field]: value,
            }
          : q
      )
    );
  };

  const updateOption = (
    questionIndex,
    optionIndex,
    value
  ) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === questionIndex
          ? {
              ...q,
              options: q.options.map((opt, j) =>
                j === optionIndex
                  ? {
                      ...opt,
                      text: value,
                    }
                  : opt
              ),
            }
          : q
      )
    );
  };

  const updateCorrectAnswer = (
    questionIndex,
    label
  ) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === questionIndex
          ? {
              ...q,
              correctAnswer: label,

              options: q.options.map((opt) => ({
                ...opt,
                correct: opt.label === label,
              })),
            }
          : q
      )
    );
  };

  const changeQuestionType = (
    questionIndex,
    type
  ) => {
    setQuestions((prev) =>
      prev.map((q, i) => {
        if (i !== questionIndex) return q;

        if (type === "TEXT") {
          return {
            questionText: q.questionText,
            type: "TEXT",
            points: q.points,
            textAnswer: "",
          };
        }

        return {
          questionText: q.questionText,
          type: "QCM",
          points: q.points,
          correctAnswer: "A",

          options: [
            {
              label: "A",
              text: "",
              correct: true,
            },
            {
              label: "B",
              text: "",
              correct: false,
            },
            {
              label: "C",
              text: "",
              correct: false,
            },
            {
              label: "D",
              text: "",
              correct: false,
            },
          ],
        };
      })
    );
  };

  /* =========================================================
     SAVE FINAL QUIZ
  ========================================================= */

  const saveQuiz = async () => {
    setError("");

    if (!questions.length) {
      setError(
        "Veuillez générer ou ajouter au moins une question."
      );
      return;
    }

    try {
      setLoadingSave(true);

      const quizPayload = {
        titre: quizInfo.titre,
        theme: quizInfo.theme,
        description: quizInfo.description,
        classe: quizInfo.classe,
        difficulty: quizInfo.difficulty,
        timeLimit: Number(quizInfo.timeLimit),

        availableFrom:
          quizInfo.availableFrom || null,

        availableUntil:
          quizInfo.availableUntil || null,

        status:
          quizInfo.publishNow === "true"
            ? "PUBLISHED"
            : "DRAFT",

        creationType: "AI",
      };

      const createdQuiz =
        await teacherQuizApi.createQuiz(
          quizPayload
        );

      const quizId = createdQuiz?.id;

      if (!quizId) {
        throw new Error(
          "Impossible de récupérer l'ID du quiz."
        );
      }

      for (const q of questions) {
        const payload = {
          questionText: q.questionText,
          type: q.type,
          points: q.points,
        };

        if (q.type === "QCM") {
          payload.correctAnswer = q.correctAnswer;

          payload.options = q.options.map(
            (opt) => ({
              label: opt.label,
              text: opt.text,
              correct:
                opt.label === q.correctAnswer,
            })
          );
        } else {
          payload.textAnswer = q.textAnswer;
        }

        await teacherQuizApi.addQuestion(
          quizId,
          payload
        );
      }

      navigate(
        `/teacher/quizzes/${quizId}/questions`
      );
    } catch (err) {
      setError(
        err?.response?.data?.message ||
          err?.message ||
          "Erreur lors de l'enregistrement du quiz."
      );
    } finally {
      setLoadingSave(false);
    }
  };

  return (
    <div className={styles.page}>
      {/* ======================================================
          HEADER
      ====================================================== */}

      <div className={styles.header}>
        <button
          type="button"
          className={styles.backBtn}
          onClick={() =>
            navigate("/teacher/quizzes/create")
          }
          aria-label="Retour"
        >
          <ArrowLeft size={22} />
        </button>

        <div className={styles.headerContent}>
          <span className={styles.badge}>
            <Brain size={16} />
            Génération IA intelligente
          </span>

          <h1>Préparer le quiz avec IA</h1>

          <p>
            Générez automatiquement des questions
            modernes, modifiez les réponses,
            améliorez le contenu puis validez le
            quiz final avant publication.
          </p>
        </div>
      </div>

      {/* ======================================================
          ERROR
      ====================================================== */}

      {error && (
        <div className={styles.errorBox}>
          {error}
        </div>
      )}

      {/* ======================================================
          SUMMARY
      ====================================================== */}

      <section className={styles.summaryCard}>
        <div>
          <span>Titre</span>
          <strong>
            {quizInfo.titre || "Non défini"}
          </strong>
        </div>

        <div>
          <span>Thème</span>
          <strong>
            {quizInfo.theme || "Non défini"}
          </strong>
        </div>

        <div>
          <span>Classe</span>
          <strong>
            {quizInfo.classe || "Non définie"}
          </strong>
        </div>

        <div>
          <span>Difficulté</span>
          <strong>
            {quizInfo.difficulty || "MOYEN"}
          </strong>
        </div>
      </section>

      {/* ======================================================
          GENERATOR
      ====================================================== */}

      <section className={styles.generatorCard}>
        <div>
          <h2>Génération automatique</h2>

          <p>
            Choisissez le nombre de questions
            puis laissez l’intelligence artificielle
            préparer le quiz.
          </p>
        </div>

        <div className={styles.generatorActions}>
          <input
            type="number"
            min="1"
            max="30"
            value={numberOfQuestions}
            onChange={(e) =>
              setNumberOfQuestions(
                e.target.value
              )
            }
          />

          <button
            type="button"
            onClick={generateQuestions}
            disabled={loadingGenerate}
          >
            <Wand2 size={18} />

            {loadingGenerate
              ? "Génération..."
              : "Générer avec IA"}
          </button>
        </div>
      </section>

      {/* ======================================================
          QUESTIONS
      ====================================================== */}

      <section className={styles.questionsSection}>
        <div className={styles.sectionHeader}>
          <div>
            <h2>Questions générées</h2>

            <p>
              Modifiez les questions avant
              l’enregistrement final.
            </p>
          </div>

          <button
            type="button"
            className={styles.addBtn}
            onClick={() => addQuestion("QCM")}
          >
            <Plus size={18} />
            Ajouter une question
          </button>
        </div>

        {!questions.length ? (
          <div className={styles.emptyBox}>
            Aucune question générée pour le
            moment.
          </div>
        ) : (
          <div className={styles.questionsList}>
            {questions.map(
              (question, questionIndex) => (
                <div
                  key={questionIndex}
                  className={styles.questionCard}
                >
                  {/* ==========================
                      TOP
                  ========================== */}

                  <div className={styles.questionTop}>
                    <span>
                      Question {questionIndex + 1}
                    </span>

                    <div
                      className={
                        styles.questionTypeRow
                      }
                    >
                      <label>Type</label>

                      <select
                        value={question.type}
                        onChange={(e) =>
                          changeQuestionType(
                            questionIndex,
                            e.target.value
                          )
                        }
                      >
                        <option value="QCM">
                          QCM
                        </option>

                        <option value="TEXT">
                          Réponse texte
                        </option>
                      </select>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        deleteQuestion(
                          questionIndex
                        )
                      }
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>

                  {/* ==========================
                      QUESTION TEXT
                  ========================== */}

                  <textarea
                    value={question.questionText}
                    placeholder="Énoncé de la question"
                    onChange={(e) =>
                      updateQuestionField(
                        questionIndex,
                        "questionText",
                        e.target.value
                      )
                    }
                  />

                  {/* ==========================
                      POINTS
                  ========================== */}

                  <div className={styles.pointsRow}>
                    <label>Points</label>

                    <input
                      type="number"
                      min="1"
                      value={question.points}
                      onChange={(e) =>
                        updateQuestionField(
                          questionIndex,
                          "points",
                          Number(
                            e.target.value
                          )
                        )
                      }
                    />
                  </div>

                  {/* ==========================
                      QCM
                  ========================== */}

                  {question.type === "QCM" && (
                    <div
                      className={
                        styles.optionsList
                      }
                    >
                      {question.options.map(
                        (
                          option,
                          optionIndex
                        ) => (
                          <div
                            key={option.label}
                            className={
                              styles.optionRow
                            }
                          >
                            <div
                              className={
                                styles.optionLetter
                              }
                            >
                              {option.label}
                            </div>

                            <input
                              type="text"
                              value={
                                option.text
                              }
                              placeholder={`Choix ${option.label}`}
                              onChange={(
                                e
                              ) =>
                                updateOption(
                                  questionIndex,
                                  optionIndex,
                                  e.target
                                    .value
                                )
                              }
                            />

                            <label
                              className={
                                styles.correctLabel
                              }
                            >
                              <input
                                type="radio"
                                name={`correct-${questionIndex}`}
                                checked={
                                  question.correctAnswer ===
                                  option.label
                                }
                                onChange={() =>
                                  updateCorrectAnswer(
                                    questionIndex,
                                    option.label
                                  )
                                }
                              />

                              Bonne réponse
                            </label>
                          </div>
                        )
                      )}
                    </div>
                  )}

                  {/* ==========================
                      TEXT ANSWER
                  ========================== */}

                  {question.type === "TEXT" && (
                    <div
                      className={
                        styles.textAnswerBlock
                      }
                    >
                      <label>
                        Réponse attendue
                      </label>

                      <textarea
                        value={
                          question.textAnswer
                        }
                        placeholder="Réponse correcte"
                        onChange={(e) =>
                          updateQuestionField(
                            questionIndex,
                            "textAnswer",
                            e.target.value
                          )
                        }
                      />
                    </div>
                  )}
                </div>
              )
            )}
          </div>
        )}
      </section>

      {/* ======================================================
          FOOTER
      ====================================================== */}

      <div className={styles.footerActions}>
        <button
          type="button"
          className={styles.secondaryBtn}
          onClick={() =>
            navigate("/teacher/quizzes/create")
          }
        >
          Annuler
        </button>

        <button
          type="button"
          className={styles.primaryBtn}
          onClick={saveQuiz}
          disabled={loadingSave}
        >
          <Save size={18} />

          {loadingSave
            ? "Enregistrement..."
            : "Enregistrer le quiz"}
        </button>
      </div>
    </div>
  );
};

export default GenerateQuizAI;