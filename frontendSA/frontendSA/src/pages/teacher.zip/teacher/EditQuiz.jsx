import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import teacherQuizApi from '../../api/teacherQuizApi';
import styles from './EditQuiz.module.css';

export default function EditQuiz() {
  const { id } = useParams();
  const nav = useNavigate();
  const [form, setForm] = useState({
    title: '',
    theme: '',
    description: '',
    duration: 30,
    startDate: '',
    endDate: '',
    published: false,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const q = await teacherQuizApi.getQuizById(id);
      setForm({
        title: q.title || q.titre || '',
        theme: q.theme || '',
        description: q.description || '',
        duration: q.duration || q.duree || 30,
        startDate: q.availableFrom || '',
        endDate: q.availableUntil || '',
        published: !!q.published,
      });
      setLoading(false);
    })();
  }, [id]);

  const change = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  async function submit(e) {
    e.preventDefault();

    const payload = {
      titre: form.title,
      theme: form.theme,
      availableFrom: form.startDate || null,
      availableUntil: form.endDate || null,
      timeLimit: Number(form.duration),
      creationType: 'MANUAL',
    };

    await teacherQuizApi.updateQuiz(id, payload);
    nav(`/teacher/quizzes/${id}`);
  }

  if (loading) return <p>Chargement...</p>;

  return (
    <div className={styles.wrap}>
      <div className={styles.title}>
        <h2>Modifier le quiz</h2>
        <p>Mettez à jour les informations du quiz.</p>
      </div>

      <form onSubmit={submit} className={styles.form}>
        <label>
          Titre
          <input name="title" value={form.title} onChange={change} />
        </label>

        <label>
          Thème
          <input name="theme" value={form.theme} onChange={change} />
        </label>

        <label>
          Description
          <textarea name="description" rows="4" value={form.description} onChange={change} />
        </label>

        <div className={styles.two}>
          <label>
            Durée
            <input type="number" name="duration" value={form.duration} onChange={change} />
          </label>

          <label>
            État
            <select
              value={String(form.published)}
              onChange={(e) => setForm((f) => ({ ...f, published: e.target.value === 'true' }))}
            >
              <option value="false">Brouillon</option>
              <option value="true">Publié</option>
            </select>
          </label>
        </div>

        <button>Enregistrer</button>
      </form>
    </div>
  );
}
