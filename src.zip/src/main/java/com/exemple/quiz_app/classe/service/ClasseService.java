package com.exemple.quiz_app.classe.service;

import com.exemple.quiz_app.auth.model.Role;
import com.exemple.quiz_app.auth.model.User;
import com.exemple.quiz_app.auth.repository.UserRepository;
import com.exemple.quiz_app.auth.service.AuthService;
import com.exemple.quiz_app.classe.dto.ClasseRequest;
import com.exemple.quiz_app.classe.dto.ClasseResponse;
import com.exemple.quiz_app.classe.dto.StudentRequest;
import com.exemple.quiz_app.classe.dto.StudentResponse;
import com.exemple.quiz_app.classe.entity.Classe;
import com.exemple.quiz_app.classe.repository.ClasseRepository;
import com.exemple.quiz_app.matiere.repository.MatiereRepository;
import com.exemple.quiz_app.quiz.entity.Quiz;
import com.exemple.quiz_app.quiz.entity.QuizStudent;
import com.exemple.quiz_app.quiz.repository.QuizRepository;
import com.exemple.quiz_app.quiz.repository.QuizStudentRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ClasseService {

    private final ClasseRepository classeRepository;
    private final UserRepository userRepository;
    private final QuizRepository quizRepository;
    private final QuizStudentRepository quizStudentRepository;
    private final MatiereRepository matiereRepository;
    private final AuthService authService;
    private final PasswordEncoder passwordEncoder;

    public ClasseService(
            ClasseRepository classeRepository,
            UserRepository userRepository,
            QuizRepository quizRepository,
            QuizStudentRepository quizStudentRepository,
            MatiereRepository matiereRepository,
            AuthService authService,
            PasswordEncoder passwordEncoder
    ) {
        this.classeRepository = classeRepository;
        this.userRepository = userRepository;
        this.quizRepository = quizRepository;
        this.quizStudentRepository = quizStudentRepository;
        this.matiereRepository = matiereRepository;
        this.authService = authService;
        this.passwordEncoder = passwordEncoder;
    }

    public List<ClasseResponse> getMyClasses() {
        User enseignant = authService.getCurrentUser();

        if (enseignant.getRole() == Role.ADMIN) {
            return getAllClasses();
        }

        return classeRepository
                .findDistinctByEnseignantOrEnseignantsContainingOrderByCreatedAtDesc(enseignant, enseignant)
                .stream()
                .map(this::toClasseResponse)
                .collect(Collectors.toList());
    }

    public List<ClasseResponse> getAllClasses() {
        User requester = authService.getCurrentUser();

        if (requester.getRole() != Role.ADMIN) {
            throw new RuntimeException("Acces reserve aux administrateurs.");
        }

        return classeRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toClasseResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public ClasseResponse createClasse(ClasseRequest request) {
        User requester = authService.getCurrentUser();

        List<User> enseignants = requester.getRole() == Role.ADMIN
                ? getSelectedTeachers(request.getTeacherIds())
                : List.of(requester);

        User enseignant = enseignants.get(0);

        if (request.getName() == null || request.getName().isBlank()) {
            throw new RuntimeException("Le nom de la classe est obligatoire.");
        }

        if (classeRepository.existsByNameAndEnseignant(request.getName().trim(), enseignant)) {
            throw new RuntimeException("Cette classe existe déjà.");
        }

        Classe classe = new Classe();
        classe.setName(request.getName().trim());
        classe.setFiliere(request.getFiliere());
        classe.setNiveau(request.getNiveau());
        classe.setEnseignant(enseignant);
        classe.setEnseignants(new HashSet<>(enseignants));

        return toClasseResponse(classeRepository.save(classe));
    }

    @Transactional
    public ClasseResponse updateClasse(Long classId, ClasseRequest request) {
        User requester = authService.getCurrentUser();

        if (requester.getRole() != Role.ADMIN) {
            throw new RuntimeException("Acces reserve aux administrateurs.");
        }

        Classe classe = classeRepository.findById(classId)
                .orElseThrow(() -> new RuntimeException("Classe introuvable."));

        if (request.getName() == null || request.getName().isBlank()) {
            throw new RuntimeException("Le nom de la classe est obligatoire.");
        }

        List<User> teachers = getSelectedTeachers(request.getTeacherIds());

        classe.setName(request.getName().trim());
        classe.setFiliere(request.getFiliere());
        classe.setNiveau(request.getNiveau());
        classe.setEnseignant(teachers.get(0));
        classe.setEnseignants(new HashSet<>(teachers));

        return toClasseResponse(classeRepository.save(classe));
    }

    @Transactional
    public ClasseResponse assignTeachersToClass(Long classId, List<Long> teacherIds) {
        User requester = authService.getCurrentUser();

        if (requester.getRole() != Role.ADMIN) {
            throw new RuntimeException("Acces reserve aux administrateurs.");
        }

        Classe classe = classeRepository.findById(classId)
                .orElseThrow(() -> new RuntimeException("Classe introuvable."));

        List<User> teachers = getSelectedTeachers(teacherIds);

        classe.setEnseignant(teachers.get(0));
        classe.setEnseignants(new HashSet<>(teachers));

        return toClasseResponse(classeRepository.save(classe));
    }

    @Transactional
    public void deleteClasse(Long classId) {
        User requester = authService.getCurrentUser();

        Classe classe = getClasseAccessibleByCurrentUser(classId, requester);

        List<User> students = userRepository.findByClasseIdOrderByLastNameAscFirstNameAsc(classId);

        for (User student : students) {
            student.setClasse(null);
            userRepository.save(student);
        }

        matiereRepository.deleteByClasseId(classId);
        classeRepository.delete(classe);
    }

    public List<StudentResponse> getStudents(Long classId) {
        User requester = authService.getCurrentUser();

        getClasseAccessibleByCurrentUser(classId, requester);

        return userRepository.findByClasseIdOrderByLastNameAscFirstNameAsc(classId)
                .stream()
                .map(this::toStudentResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public StudentResponse addStudent(Long classId, StudentRequest request) {
        User requester = authService.getCurrentUser();
        Classe classe = getClasseAccessibleByCurrentUser(classId, requester);

        if (request.getFirstName() == null || request.getFirstName().isBlank()) {
            throw new RuntimeException("Le prénom est obligatoire.");
        }

        if (request.getLastName() == null || request.getLastName().isBlank()) {
            throw new RuntimeException("Le nom est obligatoire.");
        }

        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new RuntimeException("L'email est obligatoire.");
        }

        User student = userRepository.findByEmail(request.getEmail().trim()).orElse(null);

        if (student == null) {
            if (request.getCne() != null && !request.getCne().isBlank()
                    && userRepository.existsByCne(request.getCne().trim())) {
                throw new RuntimeException("CNE deja utilise.");
            }

            if (request.getCodeApoge() != null && !request.getCodeApoge().isBlank()
                    && userRepository.existsByCodeApoge(request.getCodeApoge().trim())) {
                throw new RuntimeException("Code Apogee deja utilise.");
            }

            student = new User();
            student.setFirstName(request.getFirstName().trim());
            student.setLastName(request.getLastName().trim());
            student.setEmail(request.getEmail().trim());
            student.setRole(Role.ETUDIANT);
            student.setPassword(passwordEncoder.encode("Etudiant@123"));
            student.setMustChangePassword(true);
        } else {
            if (student.getRole() != Role.ETUDIANT) {
                throw new RuntimeException("Cet email appartient à un utilisateur qui n'est pas étudiant.");
            }

            if (request.getCne() != null && !request.getCne().isBlank()
                    && userRepository.existsByCneAndIdNot(request.getCne().trim(), student.getId())) {
                throw new RuntimeException("CNE deja utilise par un autre etudiant.");
            }

            if (request.getCodeApoge() != null && !request.getCodeApoge().isBlank()
                    && userRepository.existsByCodeApogeAndIdNot(request.getCodeApoge().trim(), student.getId())) {
                throw new RuntimeException("Code Apogee deja utilise par un autre etudiant.");
            }

            student.setFirstName(request.getFirstName().trim());
            student.setLastName(request.getLastName().trim());
        }

        student.setCne(request.getCne() != null ? request.getCne().trim() : null);
        student.setCodeApoge(request.getCodeApoge() != null ? request.getCodeApoge().trim() : null);
        student.setClasse(classe);

        return toStudentResponse(userRepository.save(student));
    }

    @Transactional
    public void deleteStudentFromClass(Long classId, Long studentId) {
        User requester = authService.getCurrentUser();

        getClasseAccessibleByCurrentUser(classId, requester);

        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Étudiant introuvable."));

        student.setClasse(null);
        userRepository.save(student);
    }

    @Transactional
    public int importStudents(Long classId, MultipartFile file) {
        User requester = authService.getCurrentUser();
        Classe classe = getClasseAccessibleByCurrentUser(classId, requester);

        int imported = 0;

        try (InputStream is = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(is)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);

                if (row == null) continue;

                boolean formOrder = getCell(row, 2).contains("@");

                String firstName = formOrder ? getCell(row, 0) : getCell(row, 1);
                String lastName = formOrder ? getCell(row, 1) : getCell(row, 2);
                String email = formOrder ? getCell(row, 2) : getCell(row, 3);
                String cne = formOrder ? getCell(row, 3) : getCell(row, 0);
                String codeApoge = getCell(row, 4);

                if (firstName.isBlank() || lastName.isBlank() || email.isBlank()
                        || cne.isBlank() || codeApoge.isBlank()) {
                    throw new RuntimeException(
                            "Ligne " + (i + 1) +
                                    " incomplete. Colonnes attendues : Prenom, Nom, Email, CNE, Code Apogee."
                    );
                }

                User student = userRepository.findByEmail(email.trim()).orElse(null);

                if (student == null && userRepository.existsByCne(cne.trim())) {
                    throw new RuntimeException("Ligne " + (i + 1) + " : CNE deja utilise.");
                }

                if (student == null && userRepository.existsByCodeApoge(codeApoge.trim())) {
                    throw new RuntimeException("Ligne " + (i + 1) + " : Code Apogee deja utilise.");
                }

                if (student != null && userRepository.existsByCneAndIdNot(cne.trim(), student.getId())) {
                    throw new RuntimeException("Ligne " + (i + 1) + " : CNE deja utilise par un autre etudiant.");
                }

                if (student != null && userRepository.existsByCodeApogeAndIdNot(codeApoge.trim(), student.getId())) {
                    throw new RuntimeException("Ligne " + (i + 1) + " : Code Apogee deja utilise par un autre etudiant.");
                }

                if (student == null) {
                    student = new User();
                    student.setFirstName(firstName.trim());
                    student.setLastName(lastName.trim());
                    student.setEmail(email.trim());
                    student.setRole(Role.ETUDIANT);
                    student.setPassword(passwordEncoder.encode("Etudiant@123"));
                    student.setMustChangePassword(true);
                } else {
                    if (student.getRole() != Role.ETUDIANT) {
                        throw new RuntimeException("Ligne " + (i + 1) + " : cet email n'appartient pas à un étudiant.");
                    }

                    student.setFirstName(firstName.trim());
                    student.setLastName(lastName.trim());
                }

                student.setCne(cne.trim());
                student.setCodeApoge(codeApoge.trim());
                student.setClasse(classe);

                userRepository.save(student);
                imported++;
            }

        } catch (Exception e) {
            throw new RuntimeException("Erreur import Excel : " + e.getMessage());
        }

        return imported;
    }

    @Transactional
    public int assignQuizToClass(Long quizId, Long classId) {
        User enseignant = authService.getCurrentUser();

        Classe classe = getClasseOwnedByTeacher(classId, enseignant);

        Quiz quiz = quizRepository.findById(quizId)
                .orElseThrow(() -> new RuntimeException("Quiz introuvable."));

        if (!quiz.getEnseignant().getId().equals(enseignant.getId())) {
            throw new RuntimeException("Vous n'êtes pas propriétaire de ce quiz.");
        }

        if (quiz.getStatus() == Quiz.QuizStatus.EXPIRED || quiz.getStatus() == Quiz.QuizStatus.DELETED) {
            throw new RuntimeException("Impossible d'affecter une classe à un quiz expiré ou supprimé.");
        }

        quiz.setClasse(classe);
        quizRepository.save(quiz);

        List<User> students = userRepository.findByClasseIdOrderByLastNameAscFirstNameAsc(classe.getId());

        int added = 0;

        for (User student : students) {
            if (!quizStudentRepository.existsByQuizAndStudent(quiz, student)) {
                QuizStudent qs = new QuizStudent();
                qs.setQuiz(quiz);
                qs.setStudent(student);
                quizStudentRepository.save(qs);
                added++;
            }
        }

        return added;
    }

    private Classe getClasseOwnedByTeacher(Long classId, User enseignant) {
        Classe classe = classeRepository.findById(classId)
                .orElseThrow(() -> new RuntimeException("Classe introuvable."));

        boolean isAdmin = enseignant.getRole() == Role.ADMIN;

        boolean isPrimaryTeacher =
                classe.getEnseignant() != null &&
                        classe.getEnseignant().getId().equals(enseignant.getId());

        boolean isAssignedTeacher =
                classe.getEnseignants() != null &&
                        classe.getEnseignants().stream()
                                .anyMatch(item -> item.getId().equals(enseignant.getId()));

        if (!isAdmin && !isPrimaryTeacher && !isAssignedTeacher) {
            throw new RuntimeException("Accès interdit à cette classe.");
        }

        return classe;
    }

    private Classe getClasseAccessibleByCurrentUser(Long classId, User requester) {
        if (requester.getRole() == Role.ADMIN) {
            return classeRepository.findById(classId)
                    .orElseThrow(() -> new RuntimeException("Classe introuvable."));
        }

        return getClasseOwnedByTeacher(classId, requester);
    }

    private ClasseResponse toClasseResponse(Classe classe) {
        ClasseResponse response = new ClasseResponse();

        response.setId(classe.getId());
        response.setName(classe.getName());
        response.setFiliere(classe.getFiliere());
        response.setNiveau(classe.getNiveau());

        response.setStudentCount(
                (long) userRepository.findByClasseIdOrderByLastNameAscFirstNameAsc(classe.getId()).size()
        );

        if (classe.getEnseignant() != null) {
            User enseignant = classe.getEnseignant();
            response.setEnseignantId(enseignant.getId());
            response.setEnseignantName(enseignant.getFirstName() + " " + enseignant.getLastName());
            response.setEnseignantEmail(enseignant.getEmail());
        }

        Set<User> enseignants = classe.getEnseignants();

        if (enseignants == null || enseignants.isEmpty()) {
            enseignants = new HashSet<>();
            if (classe.getEnseignant() != null) {
                enseignants.add(classe.getEnseignant());
            }
        }

        response.setEnseignantIds(
                enseignants.stream()
                        .map(User::getId)
                        .collect(Collectors.toList())
        );

        response.setEnseignantNames(
                enseignants.stream()
                        .map(user -> user.getFirstName() + " " + user.getLastName())
                        .collect(Collectors.toList())
        );

        return response;
    }

    private StudentResponse toStudentResponse(User user) {
        StudentResponse response = new StudentResponse();

        response.setId(user.getId());
        response.setFirstName(user.getFirstName());
        response.setLastName(user.getLastName());
        response.setEmail(user.getEmail());
        response.setCne(user.getCne());
        response.setCodeApoge(user.getCodeApoge());

        if (user.getClasse() != null) {
            response.setClassId(user.getClasse().getId());
            response.setClassName(user.getClasse().getName());
            response.setClassFiliere(user.getClasse().getFiliere());
            response.setClassNiveau(user.getClasse().getNiveau());
        }

        return response;
    }

    private List<User> getSelectedTeachers(List<Long> teacherIds) {
        if (teacherIds == null || teacherIds.isEmpty()) {
            throw new RuntimeException("Veuillez selectionner au moins un enseignant pour cette classe.");
        }

        List<User> teachers = teacherIds.stream()
                .distinct()
                .map(id -> userRepository.findById(id)
                        .orElseThrow(() -> new RuntimeException("Enseignant introuvable.")))
                .collect(Collectors.toList());

        if (teachers.stream().anyMatch(user -> user.getRole() != Role.ENSEIGNANT)) {
            throw new RuntimeException("Tous les utilisateurs selectionnes doivent etre des enseignants.");
        }

        return teachers;
    }

    private String getCell(Row row, int index) {
        Cell cell = row.getCell(index);

        if (cell == null) return "";

        cell.setCellType(CellType.STRING);

        return cell.getStringCellValue().trim();
    }
}